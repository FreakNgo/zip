# ANTIFY

A single-page, no-build, no-backend file compressor. Drop in files or whole
folder trees (folders full of folders) and ANTIFY zips them into one `.zip`,
entirely inside the browser tab — nothing is ever uploaded to a server.

## Deploying to GitHub Pages

1. Push these four files (`index.html`, `style.css`, `app.js`, `zipWorker.js`)
   to a repo.
2. Repo Settings → Pages → Deploy from branch → pick `main` / `root`.
3. Done — GitHub Pages serves static files, which is all this needs.

No `npm install`, no build step. It's plain HTML/CSS/JS plus one CDN script
(`fflate`, ~9KB gzipped) for the actual zip/deflate work.

## How the large-file handling works

- Every file is read in 4MB slices (`file.slice().arrayBuffer()`), never the
  whole file at once, so a 5–6GB file doesn't blow up mobile memory.
- Compression itself runs inside a **Web Worker**, off the main thread, so the
  page never freezes while a big batch is churning.
- On Chromium browsers (desktop Chrome/Edge, and Android Chrome), ANTIFY asks
  for a save location up front via the File System Access API and **streams
  the compressed output straight to disk** as it's produced — memory usage
  stays flat no matter how many gigabytes go through it.
- On browsers without that API (Safari, Firefox), it falls back to building
  the zip in memory and offering it as a normal download link. This works
  fine for a couple of GB but is genuinely limited by device RAM — the app
  tells the user this in the progress panel rather than silently struggling.

## Compression levels

| Option | What it does |
|---|---|
| No compression | Files are stored as-is (no deflate at all) — basically instant, useful for stuff that's already compressed like photos/video/zip-inside-zip. |
| Light | Fast deflate, modest size reduction. |
| Medium | Slower deflate, smaller output. Good default for documents/code/text-heavy folders. |

## Folder handling

Selecting **"Add a folder"** (or dragging a folder in) walks the *entire*
directory tree recursively — folders inside folders inside folders — and
preserves the relative paths inside the zip, so the structure comes out the
same on the other end.

## About the "Buy me a coffee" links

- The **Google Pay, Paytm, PhonePe, and "Any UPI app"** buttons build real
  `upi://` / app-specific deep links (`tez://`, `paytmmp://`, `phonepe://`)
  pre-filled with the UPI ID `rajveer-nanadikar@fam` and the selected amount.
  These only do anything on a phone that has the relevant app installed —
  on desktop they'll typically fail to open anything.
- There's no PayPal button — PayPal doesn't run on UPI at all (it's a
  separate, non-Indian payment network), so a "PayPal + UPI ID" link isn't a
  real thing. If you ever get a PayPal.me link, you can add a plain button
  pointing at `https://paypal.me/yourusername` alongside the UPI ones.
- Double-check the deep-link scheme names before relying on them — app
  vendors do occasionally change their custom URL schemes, and I can't
  verify them against the live apps from here.

## One file vs. four files

Both work identically once pushed to GitHub — GitHub Pages just serves
whatever static files are in the repo, it doesn't care how many there are.
- `index.html` + `style.css` + `app.js` + `zipWorker.js` (this folder): easier
  to edit piece by piece.
- `index-single.html` (single-file version, if you asked for one): CSS and JS
  are inlined, and the compression worker is embedded as a string and started
  from a Blob URL, so it's one file with no loss of functionality — drop it
  into a repo as `index.html` and it just works.

## Customizing

- Colors, fonts, and the intro animation live in `style.css` / the intro
  section of `app.js`.
- Payee name/UPI ID and preset tip amounts are constants near the bottom of
  `app.js` (`UPI_ID`, `PAYEE_NAME`).
