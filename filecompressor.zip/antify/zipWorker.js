/* Runs off the main thread so compressing 5-6GB of files never freezes the UI. */
importScripts('https://cdnjs.cloudflare.com/ajax/libs/fflate/0.8.2/fflate.min.js');

let zip = null;
const streams = Object.create(null);

function makeZip(){
  return new fflate.Zip((err, chunk, final) => {
    if (err){
      postMessage({ type:'error', error: err.message || String(err) });
      return;
    }
    // chunk is a Uint8Array — transfer its buffer back to the main thread, zero-copy
    postMessage({ type:'chunk', chunk, final }, [chunk.buffer]);
  });
}

onmessage = (e) => {
  const msg = e.data;

  try{
    switch(msg.type){
      case 'init':
        zip = makeZip();
        break;

      case 'addFileStart': {
        const level = msg.level === 0 ? 0 : msg.level;
        // level 0 -> store only (no CPU spent compressing), otherwise deflate at the chosen level
        const stream = (level === 0)
          ? new fflate.ZipPassThrough(msg.path)
          : new fflate.ZipDeflate(msg.path, { level });
        zip.add(stream);
        streams[msg.path] = stream;
        break;
      }

      case 'addFileChunk': {
        const stream = streams[msg.path];
        if (!stream) break;
        stream.push(new Uint8Array(msg.chunk), msg.final);
        if (msg.final) delete streams[msg.path];
        break;
      }

      case 'finish':
        if (zip) zip.end();
        break;
    }
  } catch(err){
    postMessage({ type:'error', error: err.message || String(err) });
  }
};
