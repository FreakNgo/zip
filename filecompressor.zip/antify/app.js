/* =====================================================================
   ANTIFY — client-side, multi-file / multi-folder zip compressor.
   Everything happens in the browser: nothing is ever uploaded anywhere.
   ===================================================================== */

/* ---------------------------------------------------------------------
   1. CINEMATIC INTRO
   --------------------------------------------------------------------- */
(function intro(){
  const introEl = document.getElementById('intro');
  const app = document.getElementById('app');
  const canvas = document.getElementById('intro-canvas');
  const ctx = canvas.getContext('2d');
  let raf, particles = [];

  function resize(){
    canvas.width = innerWidth * devicePixelRatio;
    canvas.height = innerHeight * devicePixelRatio;
    canvas.style.width = innerWidth + 'px';
    canvas.style.height = innerHeight + 'px';
    ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
  }
  resize();
  addEventListener('resize', resize);

  const cx = () => innerWidth/2, cy = () => innerHeight/2;
  const N = Math.min(70, Math.floor((innerWidth*innerHeight)/14000));
  for(let i=0;i<N;i++){
    const angle = Math.random()*Math.PI*2;
    const dist = 200 + Math.random()*Math.max(innerWidth,innerHeight)*0.5;
    particles.push({
      x: cx() + Math.cos(angle)*dist,
      y: cy() + Math.sin(angle)*dist,
      startX: cx() + Math.cos(angle)*dist,
      startY: cy() + Math.sin(angle)*dist,
      r: 1 + Math.random()*2.2,
      delay: Math.random()*0.25,
      color: Math.random() > 0.5 ? '90,60' : '74,232,196' // ember-ish / mint rgb parts
    });
  }

  const start = performance.now();
  const DURATION = 1500; // ms — particles converge over this window

  function frame(now){
    const t = (now - start) / DURATION;
    ctx.clearRect(0,0,innerWidth,innerHeight);
    particles.forEach(p=>{
      let pt = Math.max(0, Math.min(1, (t - p.delay) / (1 - p.delay)));
      const ease = 1 - Math.pow(1-pt, 3);
      const x = p.startX + (cx() - p.startX) * ease;
      const y = p.startY + (cy() - p.startY) * ease;
      const alpha = 0.55 * (1 - ease*0.85);
      ctx.beginPath();
      ctx.fillStyle = `rgba(${p.color === '90,60' ? '255,90,60' : '74,232,196'},${Math.max(alpha,0)})`;
      ctx.arc(x,y,p.r,0,Math.PI*2);
      ctx.fill();
    });
    if (t < 1.05) {
      raf = requestAnimationFrame(frame);
    }
  }
  raf = requestAnimationFrame(frame);

  function finishIntro(){
    cancelAnimationFrame(raf);
    introEl.classList.add('fade-out');
    setTimeout(()=>{
      introEl.remove();
      app.hidden = false;
    }, 550);
  }

  document.getElementById('skip-intro').addEventListener('click', finishIntro);
  setTimeout(finishIntro, 2600);
})();

/* ---------------------------------------------------------------------
   2. FILE / FOLDER COLLECTION
   --------------------------------------------------------------------- */
const state = {
  items: [],          // { path, file, size }
  pathSet: new Set(),
  level: 3
};

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('fileInput');
const folderInput = document.getElementById('folderInput');
const fileListWrap = document.getElementById('fileListWrap');
const fileListEl = document.getElementById('fileList');
const fileCountEl = document.getElementById('fileCount');
const totalSizeEl = document.getElementById('totalSize');
const compressBtn = document.getElementById('compressBtn');
const clearAllBtn = document.getElementById('clearAll');

function formatBytes(bytes){
  if (bytes === 0) return '0 B';
  const units = ['B','KB','MB','GB','TB'];
  const i = Math.floor(Math.log(bytes)/Math.log(1024));
  return `${(bytes/Math.pow(1024,i)).toFixed(i===0?0:1)} ${units[i]}`;
}

function uniquePath(path){
  if (!state.pathSet.has(path)) return path;
  const dot = path.lastIndexOf('.');
  const base = dot > 0 ? path.slice(0,dot) : path;
  const ext = dot > 0 ? path.slice(dot) : '';
  let n = 1, candidate;
  do { candidate = `${base} (${n})${ext}`; n++; } while (state.pathSet.has(candidate));
  return candidate;
}

function addFile(file, relPath){
  const path = uniquePath(relPath || file.name);
  state.pathSet.add(path);
  state.items.push({ path, file, size: file.size });
}

function renderList(){
  const count = state.items.length;
  fileListWrap.hidden = count === 0;
  compressBtn.disabled = count === 0;
  fileCountEl.textContent = `${count} item${count === 1 ? '' : 's'}`;
  const total = state.items.reduce((s,i)=>s+i.size,0);
  totalSizeEl.textContent = formatBytes(total);

  const MAX_SHOW = 200;
  fileListEl.innerHTML = '';
  state.items.slice(0, MAX_SHOW).forEach((item, idx)=>{
    const li = document.createElement('li');
    li.innerHTML = `<span class="fname" title="${item.path}">${item.path}</span><span class="fsize">${formatBytes(item.size)}</span>`;
    const rm = document.createElement('button');
    rm.className = 'fremove'; rm.type='button'; rm.textContent = '×';
    rm.addEventListener('click', ()=>{
      state.pathSet.delete(item.path);
      state.items.splice(state.items.indexOf(item),1);
      renderList();
    });
    li.appendChild(rm);
    fileListEl.appendChild(li);
  });
  if (count > MAX_SHOW){
    const li = document.createElement('li');
    li.innerHTML = `<span class="fname">+ ${count - MAX_SHOW} more…</span>`;
    fileListEl.appendChild(li);
  }
}

clearAllBtn.addEventListener('click', ()=>{
  state.items = []; state.pathSet = new Set();
  renderList();
});

fileInput.addEventListener('change', e=>{
  [...e.target.files].forEach(f => addFile(f, f.name));
  renderList();
  e.target.value = '';
});

folderInput.addEventListener('change', e=>{
  [...e.target.files].forEach(f => addFile(f, f.webkitRelativePath || f.name));
  renderList();
  e.target.value = '';
});

// keyboard / click activation for the dropzone itself
dropzone.addEventListener('click', (e)=>{
  if (e.target.closest('label')) return; // let the real buttons work
  fileInput.click();
});
dropzone.addEventListener('keydown', e=>{
  if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); }
});

// drag & drop, including whole folder trees, via webkitGetAsEntry
['dragover','dragenter'].forEach(evt=>
  dropzone.addEventListener(evt, e=>{ e.preventDefault(); dropzone.classList.add('dragover'); }));
['dragleave','drop'].forEach(evt=>
  dropzone.addEventListener(evt, e=>{ e.preventDefault(); dropzone.classList.remove('dragover'); }));

dropzone.addEventListener('drop', async e=>{
  const items = e.dataTransfer.items;
  if (items && items.length && items[0].webkitGetAsEntry){
    const entries = [...items].map(it => it.webkitGetAsEntry()).filter(Boolean);
    for (const entry of entries) await walkEntry(entry, '');
  } else {
    [...e.dataTransfer.files].forEach(f => addFile(f, f.name));
  }
  renderList();
});

function walkEntry(entry, prefix){
  return new Promise(resolve=>{
    if (entry.isFile){
      entry.file(file => { addFile(file, prefix + entry.name); resolve(); });
    } else if (entry.isDirectory){
      const reader = entry.createReader();
      const all = [];
      const readBatch = () => {
        reader.readEntries(async batch=>{
          if (!batch.length){
            for (const child of all) await walkEntry(child, prefix + entry.name + '/');
            resolve();
          } else {
            all.push(...batch);
            readBatch(); // directory readers can page results — keep reading until empty
          }
        });
      };
      readBatch();
    } else {
      resolve();
    }
  });
}

/* ---------------------------------------------------------------------
   3. COMPRESSION LEVEL SELECTION
   --------------------------------------------------------------------- */
document.querySelectorAll('.pill').forEach(pill=>{
  pill.addEventListener('click', ()=>{
    document.querySelectorAll('.pill').forEach(p=>{ p.classList.remove('active'); p.setAttribute('aria-checked','false'); });
    pill.classList.add('active');
    pill.setAttribute('aria-checked','true');
    state.level = parseInt(pill.dataset.level,10);
  });
});

/* ---------------------------------------------------------------------
   4. COMPRESSION — worker-driven, chunked, streams to disk when possible
   --------------------------------------------------------------------- */
const progressWrap = document.getElementById('progressWrap');
const progressBar = document.getElementById('progressBar');
const progressPct = document.getElementById('progressPct');
const progressSpeed = document.getElementById('progressSpeed');
const progressDone = document.getElementById('progressDone');
const progressLabel = document.getElementById('progressLabel');
const fsapiNote = document.getElementById('fsapiNote');
const downloadLink = document.getElementById('downloadLink');

const CHUNK_SIZE = 4 * 1024 * 1024; // 4MB — small enough for mobile memory, big enough to be efficient
const supportsFSA = 'showSaveFilePicker' in window;

compressBtn.addEventListener('click', async ()=>{
  if (!state.items.length) return;
  compressBtn.hidden = true;
  downloadLink.hidden = true;
  progressWrap.hidden = false;
  progressBar.style.width = '0%';
  progressPct.textContent = '0%';
  progressLabel.textContent = 'Compressing…';

  let writable = null;
  let memoryChunks = null;

  if (supportsFSA){
    try{
      const handle = await window.showSaveFilePicker({
        suggestedName: 'antify-archive.zip',
        types: [{ description: 'Zip archive', accept: { 'application/zip': ['.zip'] } }]
      });
      writable = await handle.createWritable();
      fsapiNote.textContent = 'Writing straight to disk — memory use stays flat no matter how large the batch is.';
    } catch(err){
      if (err.name === 'AbortError'){ resetAfterCompress(); return; }
      memoryChunks = [];
      fsapiNote.textContent = 'Building the zip in memory — for multi-gigabyte batches, use Chrome or Edge for direct-to-disk writing.';
    }
  } else {
    memoryChunks = [];
    fsapiNote.textContent = 'Your browser can\u2019t stream to disk, so the zip is assembled in memory. Chrome/Edge on desktop or Android handle very large batches better.';
  }

  const totalBytes = state.items.reduce((s,i)=>s+i.size, 0);
  let bytesRead = 0;
  let lastTime = performance.now();
  let lastBytes = 0;
  let writeQueue = Promise.resolve();
  let settled = false;

  const worker = new Worker('zipWorker.js');

  function updateProgress(){
    const now = performance.now();
    const pct = totalBytes ? Math.min(100, (bytesRead/totalBytes)*100) : 100;
    progressBar.style.width = pct.toFixed(1) + '%';
    progressPct.textContent = pct.toFixed(0) + '%';
    progressDone.textContent = `${formatBytes(bytesRead)} / ${formatBytes(totalBytes)}`;
    const dt = (now - lastTime)/1000;
    if (dt > 0.4){
      const speed = (bytesRead - lastBytes)/dt;
      progressSpeed.textContent = formatBytes(speed) + '/s';
      lastTime = now; lastBytes = bytesRead;
    }
  }

  function finish(success, message){
    if (settled) return;
    settled = true;
    worker.terminate();
    if (success){
      progressLabel.textContent = 'Done';
      progressBar.style.width = '100%';
      progressPct.textContent = '100%';
      if (memoryChunks){
        const blob = new Blob(memoryChunks, { type: 'application/zip' });
        downloadLink.href = URL.createObjectURL(blob);
        downloadLink.hidden = false;
      } else {
        progressLabel.textContent = 'Saved to disk';
      }
    } else {
      progressLabel.textContent = message || 'Something went wrong';
    }
    compressBtn.hidden = false;
    compressBtn.textContent = 'Compress another batch';
  }

  worker.onerror = (e)=> finish(false, 'Compression failed in the worker.');

  worker.onmessage = (e)=>{
    const msg = e.data;
    if (msg.type === 'chunk'){
      const chunk = msg.chunk;
      writeQueue = writeQueue.then(async ()=>{
        if (writable) await writable.write(chunk);
        else memoryChunks.push(chunk);
      });
      if (msg.final){
        writeQueue.then(async ()=>{
          if (writable) await writable.close();
          finish(true);
        }).catch(err=> finish(false, 'Could not finish writing the file.'));
      }
    } else if (msg.type === 'error'){
      finish(false, msg.error || 'Compression error.');
    }
  };

  worker.postMessage({ type:'init' });

  // Stream every file into the worker in fixed-size chunks, sequentially,
  // so we never hold more than one chunk of one file in memory at a time.
  (async ()=>{
    try{
      for (const item of state.items){
        worker.postMessage({ type:'addFileStart', path:item.path, level: state.level });
        const file = item.file;
        let offset = 0;
        if (file.size === 0){
          worker.postMessage({ type:'addFileChunk', path:item.path, chunk: new ArrayBuffer(0), final:true });
        }
        while (offset < file.size){
          const start = offset;
          const end = Math.min(offset + CHUNK_SIZE, file.size);
          const buf = await file.slice(start, end).arrayBuffer();
          const isFinal = end >= file.size;
          worker.postMessage({ type:'addFileChunk', path:item.path, chunk: buf, final:isFinal }, [buf]);
          bytesRead = Math.min(totalBytes, bytesRead + (end - start));
          offset = end;
          updateProgress();
          // yield to keep the main thread responsive on slow/mobile devices
          await new Promise(r=>setTimeout(r,0));
        }
      }
      worker.postMessage({ type:'finish' });
    } catch(err){
      finish(false, 'Could not read one of the files.');
    }
  })();
});

function resetAfterCompress(){
  progressWrap.hidden = true;
  compressBtn.hidden = false;
}

/* ---------------------------------------------------------------------
   5. BUY ME A COFFEE — UPI deep links
   --------------------------------------------------------------------- */
const UPI_ID = 'rajveer-nanadikar@fam';
const PAYEE_NAME = 'Rajveer Nanadikar';
let currentAmount = 25;

function buildUpiUrl(scheme, amount){
  const params = `pa=${encodeURIComponent(UPI_ID)}&pn=${encodeURIComponent(PAYEE_NAME)}&cu=INR${amount ? `&am=${amount}` : ''}`;
  return `${scheme}://pay?${params}`;
}

function refreshUpiLinks(){
  const amt = currentAmount > 0 ? currentAmount : null;
  document.getElementById('upi-gpay').href = buildUpiUrl('tez', amt);
  document.getElementById('upi-paytm').href = buildUpiUrl('paytmmp', amt);
  document.getElementById('upi-phonepe').href = buildUpiUrl('phonepe', amt);
  document.getElementById('upi-generic').href = buildUpiUrl('upi', amt);
}
refreshUpiLinks();

const customAmtWrap = document.getElementById('customAmtWrap');
const customAmt = document.getElementById('customAmt');

document.querySelectorAll('.amount').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('.amount').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const val = parseInt(btn.dataset.amt,10);
    if (val === 0){
      customAmtWrap.hidden = false;
      currentAmount = parseInt(customAmt.value,10) || 0;
    } else {
      customAmtWrap.hidden = true;
      currentAmount = val;
    }
    refreshUpiLinks();
  });
});
customAmt.addEventListener('input', ()=>{
  currentAmount = parseInt(customAmt.value,10) || 0;
  refreshUpiLinks();
});
